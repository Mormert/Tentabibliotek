#!/bin/bash

result_file=./threshold.pgm
ref_file=./threshold_ref.pgm

if [ -f $result_file ]; then
    rm $result_file
fi

if [ -f $ref_file ]; then
    rm $ref_file
fi


BIN=$1
for IMG_F in $DIRECTORY/*.pgm PGMs/*.pgm
do
    if [ -f $IMG_F ]; then
       echo "$IMG_F"
       REF=`./$REF_10 $IMG_F` 2>/dev/null
       mv $result_file $ref_file
       RES=`./$BIN $IMG_F` 2>/dev/null
       echo -n "Created:"
       if [ -f $result_file ]; then
	         echo -e "${GREEN}OK${NC}"
	         diff -qiEZw $result_file $ref_file > /dev/null
	         DIFF=$?
	         echo -n "Pixels:"
	         if [ $DIFF -eq 0 ]; then
	             echo -e "${GREEN}OK${NC}"
	         else
	             echo -e "${RED}FAIL${NC}"	
	         fi
	         #rm $result_file
       else
	         echo -e "${RED}FAIL${NC}"
           echo "No output file $result_file"
       fi
       #rm $ref_file
       echo -e "==="
    fi
done
