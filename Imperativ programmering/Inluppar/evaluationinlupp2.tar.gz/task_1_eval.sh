#!/bin/bash

zero=0
BIN=$1

IN_1=`awk -v "seed=$[(RANDOM & 32767) + 32768 * (RANDOM & 32767)]" \
       'BEGIN { srand(seed); printf("%.2f\n", rand() * 100.0) }'`
IN_2=`awk -v "seed=$[(RANDOM & 32767) + 32768 * (RANDOM & 32767)]" \
       'BEGIN { srand(seed); printf("%.2f\n", rand() * 100.0) }'`


REF=$(echo "($IN_1+$IN_2)/1"| bc -l | xargs printf %.2f)
RES=`./$BIN $IN_1 $IN_2  | xargs printf %.2f`

EVAL=$(echo $REF == $RES | bc -l)
echo -n "Sum:"
if [ $EVAL -eq 1 ]; then
    echo -e "${GREEN}OK${NC}"
else
    echo -e "${RED}FAIL${NC}"
    echo "Input:"
    echo "$IN_1 $IN_2"
    echo "Output:"
    echo $RES
    echo "Expected:"
    echo $REF
fi
