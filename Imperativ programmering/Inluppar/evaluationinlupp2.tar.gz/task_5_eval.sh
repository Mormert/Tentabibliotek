#!/bin/bash

zero=0
BIN=$1

IN_U1=`awk -v "seed=$[(RANDOM & 32767) + 32768 * (RANDOM & 32767)]" \
       'BEGIN { srand(seed); printf("%.2f\n", rand() * 50.0) }'`
IN_U2=`awk -v "seed=$[(RANDOM & 32767) + 32768 * (RANDOM & 32767)]" \
       'BEGIN { srand(seed); printf("%.2f\n", rand() * 50.0) }'`
IN_U3=`awk -v "seed=$[(RANDOM & 32767) + 32768 * (RANDOM & 32767)]" \
       'BEGIN { srand(seed); printf("%.2f\n", rand() * 50.0) }'`
IN_V1=`awk -v "seed=$[(RANDOM & 32767) + 32768 * (RANDOM & 32767)]" \
       'BEGIN { srand(seed); printf("%.2f\n", rand() * 50.0) }'`
IN_V2=`awk -v "seed=$[(RANDOM & 32767) + 32768 * (RANDOM & 32767)]" \
       'BEGIN { srand(seed); printf("%.2f\n", rand() * 50.0) }'`
IN_V3=`awk -v "seed=$[(RANDOM & 32767) + 32768 * (RANDOM & 32767)]" \
       'BEGIN { srand(seed); printf("%.2f\n", rand() * 50.0) }'`

REF[0]=$(echo "$IN_U2*$IN_V3-$IN_U3*$IN_V2"| bc -l | xargs printf %.2f)
REF[1]=$(echo "$IN_U3*$IN_V1-$IN_U1*$IN_V3"| bc -l | xargs printf %.2f)
REF[2]=$(echo "$IN_U1*$IN_V2-$IN_U2*$IN_V1"| bc -l | xargs printf %.2f)

OUT=`./$BIN $IN_U1 $IN_U2 $IN_U3 $IN_V1 $IN_V2 $IN_V3`

IFS=' ' read -r -a RES <<< "$OUT"
RES[0]=$(echo ${RES[0]} | xargs printf %.2f)
RES[1]=$(echo ${RES[1]} | xargs printf %.2f)
RES[2]=$(echo ${RES[2]} | xargs printf %.2f)

EVAL[0]=$(echo ${REF[0]} == ${RES[0]} | bc -l)
EVAL[1]=$(echo ${REF[1]} == ${RES[1]} | bc -l)
EVAL[2]=$(echo ${REF[2]} == ${RES[2]} | bc -l)

EVAL=$(echo "${EVAL[0]}+${EVAL[1]}+${EVAL[2]}"| bc -l)

echo -n "Cross product:"

if [ $EVAL == 3 ]; then
	echo -e "${GREEN}OK${NC}"
    else
	echo -e "${RED}FAIL${NC}"
	echo "Input:"
	echo "$IN_U1 $IN_U2 $IN_U3 $IN_V1 $IN_V2 $IN_V3"
	echo "Output:"
	echo "$OUT"
	echo "Expected:"
	echo "${REF[*]}"
    fi


