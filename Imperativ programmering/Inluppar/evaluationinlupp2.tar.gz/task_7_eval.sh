#!/bin/bash

BIN=$1

# case 1 source longer than destination
INP_1a=`< /dev/urandom tr -dc _A-Z-a-z | head -c10`
INP_1b=`< /dev/urandom tr -dc _A-Z-a-z | head -c5`
REF_1="$INP_1a $INP_1a"
RES_1=`./$BIN <<< "$INP_1a" "$INP_1b"`
echo -n "Source longer than destination:"
if [ "$RES_1" == "$REF_1" ]; then
    	echo -e "${GREEN}OK${NC}"
    else
	echo -e "${RED}FAIL${NC}"
	echo "Input:"
	echo "$INP_1a $INP_1b"
	echo "Output:"
	echo "$RES_1"
	echo "Expected:"
	echo "$REF_1"
fi


# case 2 destination longer than source
INP_2a=`< /dev/urandom tr -dc _A-Z-a-z | head -c5`
INP_2b=`< /dev/urandom tr -dc _A-Z-a-z | head -c10`
REF_2="$INP_2a $INP_2a"
RES_2=`./$BIN <<< "$INP_2a" "$INP_2b"`
echo -n "Destination longer than source:"
if [ "$RES_2" == "$REF_2" ]; then
    	echo -e "${GREEN}OK${NC}"
    else
	echo -e "${RED}FAIL${NC}"
	echo "Input:"
	echo "$INP_2a $INP_2b"
	echo "Output:"
	echo "$RES_2"
	echo "Expected:"
	echo "$REF_2"
fi
