#!/bin/bash

export BIN=$1
REF=`script -q -c './$BIN '`
echo $REF
unset $BIN
if [ -f typescript ]
then
    rm -f typescript
fi
