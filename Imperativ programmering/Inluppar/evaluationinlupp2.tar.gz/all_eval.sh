#!/bin/bash

if [[ $# -lt 1 ]]
then
    echo "No source directory specified!"
    echo "Usage: all_eval.sh <path to C files>"
    echo "or:    all_eval.sh clean"
    exit 1
fi

#compile reference software
export REF_9=ref_task_9
export REF_10=ref_task_10
export REF_11=ref_task_11
# gcc $REF_9.c -o $REF_9
# gcc $REF_10.c -o $REF_10
# gcc $REF_11.c -o $REF_11

export LC_NUMERIC=C #Make sure we have decimal points, not commas

#COLORS
#RED='\033[0;41m'
export RED='\e[1;49;31m'
export YELLOW='\033[1;33m'
export GREEN='\033[0;32m'
export BOLD='\033[1;166m'
export EMPH=${BOLD}
export NC='\033[0m' # No Color

#GLOBAL VARIABLES
export DIRECTORY=$1
zero=0
EV=_eval.sh
PREFIX=task_
SUFFIX=.c

#LIST OF EXPECTED ASSIGNMENTS
if [[ $2 -eq '' ]]
then
    ASSIGNMENTS_COUNT=11
else
    ASSIGNMENTS_COUNT=$2
fi


if [ $1 == "clean" ]
then
    echo "Cleaning built test binaries";
    for task_id in $(seq 1 $ASSIGNMENTS_COUNT);
    do
        task="./$PREFIX$task_id$SUFFIX"
        C_NAME=`basename $task`
        NAME=${C_NAME%.*}
        echo -e "${EMPH}$NAME${NC}"
        rm $NAME
    done
    rm *.pgm
    # rm $REF_9
    # rm $REF_10
    # rm $REF_11
   exit 1;
fi

for task_id in $(seq 1 $ASSIGNMENTS_COUNT); do
    task="$DIRECTORY/$PREFIX$task_id$SUFFIX"
    C_NAME=`basename $task`
    NAME=${C_NAME%.*}
    echo -e "${EMPH}$NAME${NC}"
    if [ -f $task ]; then
	C_OUT=`gcc -Wall -std=c99 -Werror -fdiagnostics-color=always $task -lm -o $NAME 2>&1 `
	C_RES=$?
	echo -n "compilation:"

	if [ $C_RES -eq $zero ]; then
	     echo -e "${GREEN}OK${NC}"
	    echo "==="
	    E_NAME=$NAME$EV
	    if [ -f $E_NAME ]; then
		./$E_NAME $NAME
	    fi
	else
	    echo -e "${RED}FAIL${NC}"
	    echo "==="
	    echo "Error message:"
	    echo "$C_OUT"
	fi
    else
     	echo -e "${RED}Missing file${NC}"
    fi
    echo -e "==================================="
done
