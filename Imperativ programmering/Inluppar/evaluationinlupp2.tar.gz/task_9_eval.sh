#!/bin/bash

BIN=$1
for IMG_F in $DIRECTORY/*.pgm
do
    echo -n "$IMG_F:"
    REF=`./$REF_9 $IMG_F`
    RES=`./$BIN $IMG_F`
    if [ "$RES" == "$REF" ]; then
    	echo -e "${GREEN}OK${NC}"
    else
	echo -e "${RED}FAIL${NC}"
	echo "Output:"
	echo "$RES_2"
	echo "Expected:"
	echo "$REF_2"
fi
     echo -e "==="
done
