#!/bin/bash

zero=0
BIN=$1

IN_1=`awk -v "seed=$[(RANDOM & 32767) + 32768 * (RANDOM & 32767)]" \
       'BEGIN { srand(seed); printf("%.2f\n", rand() * 100.0) }'`
IN_2=`awk -v "seed=$[(RANDOM & 32767) + 32768 * (RANDOM & 32767)]" \
       'BEGIN { srand(seed); printf("%.2f\n", rand() * 100.0) }'`
IN_3=`awk -v "seed=$[(RANDOM & 32767) + 32768 * (RANDOM & 32767)]" \
       'BEGIN { srand(seed); printf("%.2f\n", rand() * 100.0) }'`


REF=($IN_3 $IN_2 $IN_1)
RES=`./$BIN $IN_1 $IN_2 $IN_3`
IFS=' ' read -r -a RES <<< "$RES"
RES[0]=$(echo ${RES[0]} | xargs printf %.2f)
RES[1]=$(echo ${RES[1]} | xargs printf %.2f)
RES[2]=$(echo ${RES[2]} | xargs printf %.2f)

EVAL[0]=$(echo ${REF[0]} == ${RES[0]} | bc -l)
EVAL[1]=$(echo ${REF[1]} == ${RES[1]} | bc -l)
EVAL[2]=$(echo ${REF[2]} == ${RES[2]} | bc -l)

EVAL=$(echo "${EVAL[0]}+${EVAL[1]}+${EVAL[2]}"| bc -l)
echo -n "Sequence:"
if [ $EVAL == 3 ]; then
	echo -e "${GREEN}OK${NC}"
    else
	echo -e "${RED}FAIL${NC}"
        echo "Input:"
        echo "$IN_1 $IN_2 $IN_3"
        echo "Output:"
	echo "${RES[@]}"
	echo "Expected:"
	echo "${REF[@]}"


    fi

