#!/bin/bash

zero=0
BIN=$1

# case1 rhyme 3+ letters even
INP_1=`< /dev/urandom tr -dc _A-Z-a-z | head -c6`
REF_1="ja"
RES_1=`./$BIN $INP_1 $INP_1`
RET=$?
echo -n "Rhyme 3+ letters even:"
if [ "$RES_1" == "$REF_1" ] && [ $RET -eq 0 ] ; then
    	echo -e "${GREEN}OK${NC}"
    else
	echo -e "${RED}FAIL${NC}"
	echo "Input:"
	echo "$INP_1 $INP_1"
	echo "Output:"
	echo "$RES_1"
	echo "Expected:"
	echo "$REF_1"
        echo "Return value:"
        echo "$RET"
        echo "Expected:"
        echo "0"
fi

# case2 rhyme 3+ letters uneven
INP_2a=`< /dev/urandom tr -dc _A-Z-a-z | head -c6`
INP_2b=`echo $INP_2a | tail -c4`
REF_2=ja
RES_2=`./$BIN $INP_2a $INP_2b`
RET=$?
echo -n "Rhyme 3+ letters uneven:"
if [ "$RES_2" == "$REF_2" ] && [ $RET -eq 0 ] ; then
    	echo -e "${GREEN}OK${NC}"
    else
	echo -e "${RED}FAIL${NC}"
	echo "Input:"
	echo "$INP_2a $INP_2b"
	echo "Output:"
	echo "$RES_2"
	echo "Expected:"
	echo "$REF_2"
        echo "Return value:"
        echo "$RET"
        echo "Expected:"
        echo "0"
fi

# case3 not rhyme 3+ letters even
INP_3a=`< /dev/urandom tr -dc _A-Z-a-z | head -c6`
INP_3b=`< /dev/urandom tr -dc _A-Z-a-z | head -c6`
REF_3=nej
RES_3=`./$BIN $INP_3a $INP_3b`
RET=$?
echo -n "Not rhyme 3+ letters uneven:"
if [ "$RES_3" == "$REF_3" ] && [ $RET -eq 1 ] ; then
    	echo -e "${GREEN}OK${NC}"
    else
	echo -e "${RED}FAIL${NC}"
	echo "Input:"
	echo "$INP_3a $INP_3b"
	echo "Output:"
	echo "$RES_3"
	echo "Expected:"
	echo "$REF_3"
        echo "Return value:"
        echo "$RET"
        echo "Expected:"
        echo "1"
fi



# case4 3- letters
INP_4a=`< /dev/urandom tr -dc _A-Z-a-z | head -c2`
INP_4b=`< /dev/urandom tr -dc _A-Z-a-z | head -c2`
REF_4=nej
RES_4=`./$BIN $INP_4a $INP_4b`
RET=$?
echo -n "Not rhyme 3- even:"
if [ "$RES_4" == "$REF_4" ] && [ $RET -eq 1 ] ; then
    	echo -e "${GREEN}OK${NC}"
    else
	echo -e "${RED}FAIL${NC}"
	echo "Input:"
	echo "$INP_4a $INP_4b"
	echo "Output:"
	echo "$RES_4"
	echo "Expected:"
	echo "$REF_4"
        echo "Return value:"
        echo "$RET"
        echo "Expected:"
        echo "1"
fi
