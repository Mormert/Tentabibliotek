#!/bin/bash
# Compilation


zero=0
BIN=$1

RANGE=10
R=$RANDOM
let "R %= $RANGE"
R=$(($R+1))
R=7

RES=`./$BIN <<< "$R"`
echo "$RES"

