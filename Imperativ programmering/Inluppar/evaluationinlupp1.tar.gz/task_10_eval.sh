#!/bin/bash
# Compilation

BIN=$1
PI="3.1415"
RANGE=4
R=$RANDOM
let "R %= $RANGE"
R=$(($R+1))
A_ref=$(echo "scale=2; $PI*$R*$R/1" | bc -l | xargs printf %.2f)

echo "input:"
echo "$R"
echo "reference:"
echo "$A_ref"
echo "===="
echo "Interactive input"

RES=`./$BIN <<< $R |tail`
echo "output:"
echo "$RES" 

echo "===="
echo "No input"
RES=`./$BIN <<< /dev/null |tail`
echo "output:"
echo "$RES" 


