#!/bin/bash
# Compilation

zero=0
BIN=$1

failed=0

for x in `seq 3`
do
    RES=`./$BIN`
    res[$x]=`./$BIN`
    sleep 1
done

for x in `seq 3`
do
    #echo ${res[$x]}
    if [[ ${res[$x]} -lt 1 || ${res[$x]} -gt 6 ]]
    then
        failed=1
    fi
done

if [ "${#res[@]}" -gt 0 ] && [ $(printf "%s\000" "${res[@]}" | 
       LC_ALL=C sort -z -u |
       grep -z -c .) -eq 1 ] ; then
    failed=1
fi


if [ $failed -eq 0 ]
then
    echo -e "${GREEN}OK${NC}"
    echo "Got these random numbers: ${res[*]}"
else
    echo -e "${RED}FAIL${NC}"
    echo "Got these random numbers: ${res[*]}"
fi


