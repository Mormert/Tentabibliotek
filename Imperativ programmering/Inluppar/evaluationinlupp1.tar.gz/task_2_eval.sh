#!/bin/bash

#GLOBAL VARIABLES
zero=0
BIN=$1
PI="3.1415"
R=1



    A_ref=$(echo "scale=2; $PI*$R*$R/1" | bc -l | xargs printf %.2f)
    O_ref=$(echo "scale=2; 2*$PI*$R/1" | bc -l | xargs printf %.2f)
    
    RES=`./$BIN`
    A=$(echo "$RES" | grep "Area")
    IFS=' ' read -r -a A <<< "$A"
    O=$(echo "$RES" | grep "Omkrets")
    IFS=' ' read -r -a O <<< "$O"
    
    A=$(echo ${A[-1]} | xargs printf %.2f)
    O=$(echo ${O[-1]} | xargs printf %.2f)

    echo -n "Area: "
    st=`echo "$A == $A_ref" | bc`
    if [ $st -eq 1 ]; then
	 echo -e "${GREEN}OK${NC}"
    else
	echo -e "${RED}FAIL${NC}"
	echo "input"
	echo $R
	echo "output:"
	echo "$A $O"
	echo "reference:"
	echo "$A_ref $O_ref"
    fi
    
    echo -n "Length: "
    st=`echo "$O == $O_ref" | bc`
    if [ $st -eq 1 ]; then
	echo -e "${GREEN}OK${NC}"
    else
	echo -e "${RED}FAIL${NC}"
	echo "input"
	echo $R
	echo "output:"
	echo "$A $O"
	echo "reference:"
	echo "$A_ref $O_ref"
    fi


