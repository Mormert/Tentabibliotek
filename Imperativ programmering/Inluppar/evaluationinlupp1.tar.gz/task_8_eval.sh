#!/bin/bash
# Compilation


zero=0
BIN=$1

INPUT="2 29";
RES=`./$BIN <<< "$INPUT"`
echo $RES
