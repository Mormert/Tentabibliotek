#!/bin/bash
# Compilation

zero=0
BIN=$1
SOLUTION="2 4 5 6 8 10 12 14 15 16 18 20";
IFS=' ' read -r -a SOLUTION_ARR <<< "$SOLUTION"
RES=`./$BIN`
IFS=' \n\t' read -r -a RES_ARR <<< "$RES"
diff=$(diff <(printf "%s\n" "${SOLUTION_ARR[@]}") <(printf "%s\n" "${RES_ARR[@]}"))

echo -n "sequence: "
if [[ -z "$diff" ]]; then
    echo -e "${GREEN}OK${NC}"
else
    echo -e "${RED}FAIL${NC}"
    echo "expected"
    echo "$SOLUTION"
    echo "output"
    echo "$RES"
fi

