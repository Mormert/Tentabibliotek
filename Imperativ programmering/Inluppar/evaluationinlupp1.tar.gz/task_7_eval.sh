#!/bin/bash
# Compilation


zero=0
BIN=$1

INPUT="2 29";
RES=`./$BIN <<< "$INPUT"`
echo $RES

# zero=0
# BIN=$1
# #SOLUTION=(2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73 79 83 89 97);
# SOLUTION=(1 3 6 10 15 21 28 36 45 55);

# RES=`./$BIN`

# IFS=' \t\n' read -r -a array <<< "$RES"
# echo -n "array size:"
# if [ ${#array[@]} -eq  10 ]; then
#     echo -e "${GREEN}OK${NC}"
#     echo -n "array content:"
#     diff=$(diff <(printf "%s\n" "${array[@]}") <(printf "%s\n" "${SOLUTION[@]}"))

#     if [[ -z "$diff" ]]; then
# 	echo -e "${GREEN}OK${NC}"
#     else
# 	echo -e "${RED}FAIL${NC}"
# 	echo "Array size: ${#array[@]}"
# 	echo "Array content: ${array[@]}"
#     fi
    
# else
#     echo -e "${RED}FAIL${NC}"
#     echo "Array size: ${#array[@]}"
#     echo "Array content: ${array[@]}"
# fi


