#!/bin/bash

if [[ $# -lt 1 ]]
then
    echo "No source directory specified!"
    echo "Usage: all_eval.sh <path to C files>"
    echo "or:    all_eval.sh clean"
    exit 1
fi

export LC_NUMERIC=C #Make sure we have decimal points, not commas

#COLORS
#export RED='\033[0;41m'
export RED='\033[1;49;31m'
export YELLOW='\033[1;33m'
export GREEN='\033[0;32m'
export BOLD='\033[1;166m'
export EMPH=${BOLD}
export NC='\033[0m' # No Color

#GLOBAL VARIABLES
DIRECTORY=$1
LOGDIR="./"
zero=0
EV=_eval.sh
PREFIX=task_
LOG=log
SUFFIX=.c

#LIST OF EXPECTED ASSIGNMENTS
if [[ $2 -eq '' ]]
then
    ASSIGNMENTS_COUNT=11
else
    ASSIGNMENTS_COUNT=$2
fi


if [ $1 == "clean" ]
then
    echo "Cleaning built test binaries and logs";
    rm $LOGDIR$LOG
    for task_id in $(seq 1 $ASSIGNMENTS_COUNT);
    do
        task="./$PREFIX$task_id$SUFFIX"
        C_NAME=`basename $task`
        NAME=${C_NAME%.*}
        echo -e "${EMPH}$NAME${NC}"
        rm $NAME
    done
   exit 1;
fi



for task_id in $(seq 1 $ASSIGNMENTS_COUNT); do
#for task_id in $(seq 1 9); do
    task="$DIRECTORY$PREFIX$task_id$SUFFIX"
    C_NAME=`basename $task`
    NAME=${C_NAME%.*}
    # echo -e "${EMPH}$NAME${NC}"
    LOG[$task_id]="${EMPH}$NAME${NC}"
    if [ -f $task ]; then
	C_OUT=`gcc -Wall -std=c99 -Werror -fdiagnostics-color=always $task -lm -o $NAME 2>&1 `
	C_RES=$?
	#echo -n "compilation:"
	LOG[$task_id]="${LOG[$task_id]}\ncompilation"
	if [ $C_RES -eq $zero ]; then
	    #echo -e "${GREEN}OK${NC}"
	    LOG[$task_id]="${LOG[$task_id]} ${GREEN}OK${NC}"
	    #echo "==="
	    LOG[$task_id]="${LOG[$task_id]}\n==="
	    E_NAME=$NAME$EV
	    if [ -f $E_NAME ]; then
		EVAL_OUT=`./$E_NAME $NAME 2>&1`
		LOG[$task_id]="${LOG[$task_id]}\n$EVAL_OUT"
	    fi
	else
	    LOG[$task_id]="${LOG[$task_id]}\n${RED}FAIL${NC}\n===\nError message:$C_OUT"
	    #echo -e "${RED}FAIL${NC}"
	    #echo "==="
	    #echo "Error message:"
	    #echo "$C_OUT"
	    echo " "
	fi
    else
	LOG[$task_id]="${LOG[$task_id]}\n${RED}Missing file${NC}"
     	#echo -e "${RED}Missing file${NC}"
    fi
    LOG[$task_id]="${LOG[$task_id]}\n==================================="
    #echo -e "==================================="
    echo -e "${LOG[$task_id]}"
done

for task_id in $(seq 1 $ASSIGNMENTS_COUNT); do
    task="$DIRECTORY$PREFIX$task_id$SUFFIX"
    C_NAME=`basename $task`
    NAME=${C_NAME%.*}
    #    echo -e "${LOG[$task_id]}"
    LOG[$task_id]=`echo -e "${LOG[$task_id]}" | sed -r "s/\x1B\[([0-9]{1,2}(;[0-9]{1,3}(;[0-9]{1,2})?)?)?[mGK]//g"`
    echo -e "${LOG[$task_id]}" >> "$LOGDIR$LOG"
    if [ -f $task ]; then
	CODE=`cat $task`
	cat $task >> "$LOGDIR$LOG"
	#LOG[$task_id]="${LOG[$task_id]}\n$CODE"
	
    else
	#LOG[$task_id]="${LOG[$task_id]}\nMissing file"
	echo "\nMissing file" >> "$LOGDIR$LOG"
     	#echo -e "${RED}Missing file${NC}"
    fi
    	echo "===================================" >> "$LOGDIR$LOG"
    #LOG[$task_id]="${LOG[$task_id]}\n==================================="
    #echo -e "==================================="
    #echo "${LOG[$task_id]}" >> "$LOGDIR$LOG"
    
    
    
done
