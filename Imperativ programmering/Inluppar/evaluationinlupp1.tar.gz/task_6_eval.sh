#!/bin/bash
# Compilation

zero=0
BIN=$1
SOLUTION="2 4 5 6 8 10 12 14 15 16 18 20";

INPUT="2 29";
RES=`./$BIN <<< "$INPUT"`
echo $RES

