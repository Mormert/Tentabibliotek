#!/bin/bash
# Compilation

BIN=$1
RES=`./$BIN`
echo "output:"
echo "$RES"


